#ifndef LIBASM_H
#define LIBASM_H

#include <stdint.h>

void saveRegisters(uint64_t* regs);

#endif