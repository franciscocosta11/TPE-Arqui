#ifndef SHELL_H
#define SHELL_H
#include "libc.h"

// inicializa la famosa shell
void shell();

#endif // SHELL_H